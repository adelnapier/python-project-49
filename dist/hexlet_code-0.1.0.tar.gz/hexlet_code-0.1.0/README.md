### Hexlet tests and linter status:
[![Actions Status](https://github.com/adelnapier/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/adelnapier/python-project-49/actions)

# Brain Even Game

## Установка пакета и пример игры

[![asciicast](https://asciinema.org/a/vTImwVtMwWsXhmKM8iMXHntO1.svg)](https://asciinema.org/a/vTImwVtMwWsXhmKM8iMXHntO1)

# Brain Calculater Game

## Установка пакета и пример игры

[![asciicast](https://asciinema.org/a/CckTVDTfTt8TqiuWblHxorkJE.svg)](https://asciinema.org/a/CckTVDTfTt8TqiuWblHxorkJE)

# Brain GCD Game

## Установка пакета и пример игры

[![asciicast](https://asciinema.org/a/YOUR_ASCINEMA_ID.svg)](https://asciinema.org/a/YOUR_ASCINEMA_ID)
